export type StillQuote = {
  id: string;
  text: string;
  category: string;
  tags: string[];
  tone: string;
  attribution: null;
};

export const stillQuotes: StillQuote[] = [
  {
    "id": "everyday-001",
    "text": "You are allowed to take today gently.",
    "category": "everyday",
    "tags": [
      "dashboard",
      "general"
    ],
    "tone": "gentle",
    "attribution": null
  },
  {
    "id": "everyday-002",
    "text": "A small step still changes the day.",
    "category": "everyday",
    "tags": [
      "dashboard",
      "general"
    ],
    "tone": "gentle",
    "attribution": null
  },
  {
    "id": "everyday-003",
    "text": "Begin where your feet already are.",
    "category": "everyday",
    "tags": [
      "dashboard",
      "general"
    ],
    "tone": "gentle",
    "attribution": null
  },
  {
    "id": "everyday-004",
    "text": "There is room for ease today.",
    "category": "everyday",
    "tags": [
      "dashboard",
      "general"
    ],
    "tone": "gentle",
    "attribution": null
  },
  {
    "id": "everyday-005",
    "text": "Let today be simple and honest.",
    "category": "everyday",
    "tags": [
      "dashboard",
      "general"
    ],
    "tone": "gentle",
    "attribution": null
  },
  {
    "id": "everyday-006",
    "text": "You do not need to hurry your life.",
    "category": "everyday",
    "tags": [
      "dashboard",
      "general"
    ],
    "tone": "gentle",
    "attribution": null
  },
  {
    "id": "everyday-007",
    "text": "One kind choice can soften everything.",
    "category": "everyday",
    "tags": [
      "dashboard",
      "general"
    ],
    "tone": "gentle",
    "attribution": null
  },
  {
    "id": "everyday-008",
    "text": "Your pace is still a valid pace.",
    "category": "everyday",
    "tags": [
      "dashboard",
      "general"
    ],
    "tone": "gentle",
    "attribution": null
  },
  {
    "id": "everyday-009",
    "text": "Notice what is already going right.",
    "category": "everyday",
    "tags": [
      "dashboard",
      "general"
    ],
    "tone": "gentle",
    "attribution": null
  },
  {
    "id": "everyday-010",
    "text": "You can start again from this moment.",
    "category": "everyday",
    "tags": [
      "dashboard",
      "general"
    ],
    "tone": "gentle",
    "attribution": null
  },
  {
    "id": "everyday-011",
    "text": "Make space for what matters quietly.",
    "category": "everyday",
    "tags": [
      "dashboard",
      "general"
    ],
    "tone": "gentle",
    "attribution": null
  },
  {
    "id": "everyday-012",
    "text": "Today does not need to be perfect.",
    "category": "everyday",
    "tags": [
      "dashboard",
      "general"
    ],
    "tone": "gentle",
    "attribution": null
  },
  {
    "id": "everyday-013",
    "text": "Keep what helps. Release what does not.",
    "category": "everyday",
    "tags": [
      "dashboard",
      "general"
    ],
    "tone": "gentle",
    "attribution": null
  },
  {
    "id": "everyday-014",
    "text": "Let enough be enough for today.",
    "category": "everyday",
    "tags": [
      "dashboard",
      "general"
    ],
    "tone": "gentle",
    "attribution": null
  },
  {
    "id": "everyday-015",
    "text": "You are building a life, not racing one.",
    "category": "everyday",
    "tags": [
      "dashboard",
      "general"
    ],
    "tone": "gentle",
    "attribution": null
  },
  {
    "id": "everyday-016",
    "text": "Tiny progress deserves to be noticed.",
    "category": "everyday",
    "tags": [
      "dashboard",
      "general"
    ],
    "tone": "gentle",
    "attribution": null
  },
  {
    "id": "everyday-017",
    "text": "Choose the next gentle thing.",
    "category": "everyday",
    "tags": [
      "dashboard",
      "general"
    ],
    "tone": "gentle",
    "attribution": null
  },
  {
    "id": "everyday-018",
    "text": "Your day can change one moment at a time.",
    "category": "everyday",
    "tags": [
      "dashboard",
      "general"
    ],
    "tone": "gentle",
    "attribution": null
  },
  {
    "id": "everyday-019",
    "text": "Some days are for becoming, slowly.",
    "category": "everyday",
    "tags": [
      "dashboard",
      "general"
    ],
    "tone": "gentle",
    "attribution": null
  },
  {
    "id": "everyday-020",
    "text": "Let your life feel like yours.",
    "category": "everyday",
    "tags": [
      "dashboard",
      "general"
    ],
    "tone": "gentle",
    "attribution": null
  },
  {
    "id": "morning-001",
    "text": "The day is new, and so are your choices.",
    "category": "morning",
    "tags": [
      "time-of-day",
      "morning"
    ],
    "tone": "hopeful",
    "attribution": null
  },
  {
    "id": "morning-002",
    "text": "Wake slowly. The world can wait a moment.",
    "category": "morning",
    "tags": [
      "time-of-day",
      "morning"
    ],
    "tone": "hopeful",
    "attribution": null
  },
  {
    "id": "morning-003",
    "text": "Start softly, then find your rhythm.",
    "category": "morning",
    "tags": [
      "time-of-day",
      "morning"
    ],
    "tone": "hopeful",
    "attribution": null
  },
  {
    "id": "morning-004",
    "text": "Morning light is an invitation, not a deadline.",
    "category": "morning",
    "tags": [
      "time-of-day",
      "morning"
    ],
    "tone": "hopeful",
    "attribution": null
  },
  {
    "id": "morning-005",
    "text": "Choose one thing to begin with care.",
    "category": "morning",
    "tags": [
      "time-of-day",
      "morning"
    ],
    "tone": "hopeful",
    "attribution": null
  },
  {
    "id": "morning-006",
    "text": "You do not have to earn a peaceful morning.",
    "category": "morning",
    "tags": [
      "time-of-day",
      "morning"
    ],
    "tone": "hopeful",
    "attribution": null
  },
  {
    "id": "morning-007",
    "text": "Let the first hour belong to you.",
    "category": "morning",
    "tags": [
      "time-of-day",
      "morning"
    ],
    "tone": "hopeful",
    "attribution": null
  },
  {
    "id": "morning-008",
    "text": "Open the day with something kind.",
    "category": "morning",
    "tags": [
      "time-of-day",
      "morning"
    ],
    "tone": "hopeful",
    "attribution": null
  },
  {
    "id": "morning-009",
    "text": "A quiet beginning can hold a strong day.",
    "category": "morning",
    "tags": [
      "time-of-day",
      "morning"
    ],
    "tone": "hopeful",
    "attribution": null
  },
  {
    "id": "morning-010",
    "text": "Breathe before the notifications begin.",
    "category": "morning",
    "tags": [
      "time-of-day",
      "morning"
    ],
    "tone": "hopeful",
    "attribution": null
  },
  {
    "id": "morning-011",
    "text": "Today is waiting, not chasing you.",
    "category": "morning",
    "tags": [
      "time-of-day",
      "morning"
    ],
    "tone": "hopeful",
    "attribution": null
  },
  {
    "id": "morning-012",
    "text": "Carry this softness into the day.",
    "category": "morning",
    "tags": [
      "time-of-day",
      "morning"
    ],
    "tone": "hopeful",
    "attribution": null
  },
  {
    "id": "afternoon-001",
    "text": "Pause. The day is still yours.",
    "category": "afternoon",
    "tags": [
      "time-of-day",
      "afternoon"
    ],
    "tone": "grounding",
    "attribution": null
  },
  {
    "id": "afternoon-002",
    "text": "You can reset without starting over.",
    "category": "afternoon",
    "tags": [
      "time-of-day",
      "afternoon"
    ],
    "tone": "grounding",
    "attribution": null
  },
  {
    "id": "afternoon-003",
    "text": "The afternoon can be a second beginning.",
    "category": "afternoon",
    "tags": [
      "time-of-day",
      "afternoon"
    ],
    "tone": "grounding",
    "attribution": null
  },
  {
    "id": "afternoon-004",
    "text": "Return to what matters, gently.",
    "category": "afternoon",
    "tags": [
      "time-of-day",
      "afternoon"
    ],
    "tone": "grounding",
    "attribution": null
  },
  {
    "id": "afternoon-005",
    "text": "Take a breath between one thing and another.",
    "category": "afternoon",
    "tags": [
      "time-of-day",
      "afternoon"
    ],
    "tone": "grounding",
    "attribution": null
  },
  {
    "id": "afternoon-006",
    "text": "You have already made it this far.",
    "category": "afternoon",
    "tags": [
      "time-of-day",
      "afternoon"
    ],
    "tone": "grounding",
    "attribution": null
  },
  {
    "id": "afternoon-007",
    "text": "Leave some energy for yourself.",
    "category": "afternoon",
    "tags": [
      "time-of-day",
      "afternoon"
    ],
    "tone": "grounding",
    "attribution": null
  },
  {
    "id": "afternoon-008",
    "text": "Slow down enough to notice the day.",
    "category": "afternoon",
    "tags": [
      "time-of-day",
      "afternoon"
    ],
    "tone": "grounding",
    "attribution": null
  },
  {
    "id": "evening-001",
    "text": "Let the day loosen its grip.",
    "category": "evening",
    "tags": [
      "time-of-day",
      "evening"
    ],
    "tone": "unwinding",
    "attribution": null
  },
  {
    "id": "evening-002",
    "text": "You have done enough to come home to yourself.",
    "category": "evening",
    "tags": [
      "time-of-day",
      "evening"
    ],
    "tone": "unwinding",
    "attribution": null
  },
  {
    "id": "evening-003",
    "text": "The evening does not need your productivity.",
    "category": "evening",
    "tags": [
      "time-of-day",
      "evening"
    ],
    "tone": "unwinding",
    "attribution": null
  },
  {
    "id": "evening-004",
    "text": "Put down what can wait until tomorrow.",
    "category": "evening",
    "tags": [
      "time-of-day",
      "evening"
    ],
    "tone": "unwinding",
    "attribution": null
  },
  {
    "id": "evening-005",
    "text": "Let the light soften everything.",
    "category": "evening",
    "tags": [
      "time-of-day",
      "evening"
    ],
    "tone": "unwinding",
    "attribution": null
  },
  {
    "id": "evening-006",
    "text": "You can close the day without solving it.",
    "category": "evening",
    "tags": [
      "time-of-day",
      "evening"
    ],
    "tone": "unwinding",
    "attribution": null
  },
  {
    "id": "evening-007",
    "text": "Make room for comfort tonight.",
    "category": "evening",
    "tags": [
      "time-of-day",
      "evening"
    ],
    "tone": "unwinding",
    "attribution": null
  },
  {
    "id": "evening-008",
    "text": "The unfinished things can rest too.",
    "category": "evening",
    "tags": [
      "time-of-day",
      "evening"
    ],
    "tone": "unwinding",
    "attribution": null
  },
  {
    "id": "evening-009",
    "text": "Notice what carried you through today.",
    "category": "evening",
    "tags": [
      "time-of-day",
      "evening"
    ],
    "tone": "unwinding",
    "attribution": null
  },
  {
    "id": "evening-010",
    "text": "Welcome the quieter part of the day.",
    "category": "evening",
    "tags": [
      "time-of-day",
      "evening"
    ],
    "tone": "unwinding",
    "attribution": null
  },
  {
    "id": "night-001",
    "text": "Rest does not need to be earned.",
    "category": "night",
    "tags": [
      "time-of-day",
      "night"
    ],
    "tone": "restful",
    "attribution": null
  },
  {
    "id": "night-002",
    "text": "Tomorrow can hold tomorrow.",
    "category": "night",
    "tags": [
      "time-of-day",
      "night"
    ],
    "tone": "restful",
    "attribution": null
  },
  {
    "id": "night-003",
    "text": "Let your thoughts settle at their own pace.",
    "category": "night",
    "tags": [
      "time-of-day",
      "night"
    ],
    "tone": "restful",
    "attribution": null
  },
  {
    "id": "night-004",
    "text": "The night is allowed to be quiet.",
    "category": "night",
    "tags": [
      "time-of-day",
      "night"
    ],
    "tone": "restful",
    "attribution": null
  },
  {
    "id": "night-005",
    "text": "You can release the day now.",
    "category": "night",
    "tags": [
      "time-of-day",
      "night"
    ],
    "tone": "restful",
    "attribution": null
  },
  {
    "id": "night-006",
    "text": "Close your eyes. Nothing needs fixing tonight.",
    "category": "night",
    "tags": [
      "time-of-day",
      "night"
    ],
    "tone": "restful",
    "attribution": null
  },
  {
    "id": "night-007",
    "text": "Your body deserves a peaceful ending.",
    "category": "night",
    "tags": [
      "time-of-day",
      "night"
    ],
    "tone": "restful",
    "attribution": null
  },
  {
    "id": "night-008",
    "text": "Leave a little tenderness for yourself.",
    "category": "night",
    "tags": [
      "time-of-day",
      "night"
    ],
    "tone": "restful",
    "attribution": null
  },
  {
    "id": "night-009",
    "text": "The stars are not in a hurry either.",
    "category": "night",
    "tags": [
      "time-of-day",
      "night"
    ],
    "tone": "restful",
    "attribution": null
  },
  {
    "id": "night-010",
    "text": "Sleep is part of moving forward.",
    "category": "night",
    "tags": [
      "time-of-day",
      "night"
    ],
    "tone": "restful",
    "attribution": null
  },
  {
    "id": "work-focus-001",
    "text": "One clear task is enough to begin.",
    "category": "work-focus",
    "tags": [
      "work",
      "focus"
    ],
    "tone": "focused",
    "attribution": null
  },
  {
    "id": "work-focus-002",
    "text": "Focus on the next visible step.",
    "category": "work-focus",
    "tags": [
      "work",
      "focus"
    ],
    "tone": "focused",
    "attribution": null
  },
  {
    "id": "work-focus-003",
    "text": "Done with care beats rushed and perfect.",
    "category": "work-focus",
    "tags": [
      "work",
      "focus"
    ],
    "tone": "focused",
    "attribution": null
  },
  {
    "id": "work-focus-004",
    "text": "Make progress, then make space.",
    "category": "work-focus",
    "tags": [
      "work",
      "focus"
    ],
    "tone": "focused",
    "attribution": null
  },
  {
    "id": "work-focus-005",
    "text": "You can work without abandoning yourself.",
    "category": "work-focus",
    "tags": [
      "work",
      "focus"
    ],
    "tone": "focused",
    "attribution": null
  },
  {
    "id": "work-focus-006",
    "text": "Clarity often arrives after you begin.",
    "category": "work-focus",
    "tags": [
      "work",
      "focus"
    ],
    "tone": "focused",
    "attribution": null
  },
  {
    "id": "work-focus-007",
    "text": "Protect your attention like something precious.",
    "category": "work-focus",
    "tags": [
      "work",
      "focus"
    ],
    "tone": "focused",
    "attribution": null
  },
  {
    "id": "work-focus-008",
    "text": "Small, steady effort still counts.",
    "category": "work-focus",
    "tags": [
      "work",
      "focus"
    ],
    "tone": "focused",
    "attribution": null
  },
  {
    "id": "work-focus-009",
    "text": "Finish the important thing before the loud thing.",
    "category": "work-focus",
    "tags": [
      "work",
      "focus"
    ],
    "tone": "focused",
    "attribution": null
  },
  {
    "id": "work-focus-010",
    "text": "Take breaks before your body demands them.",
    "category": "work-focus",
    "tags": [
      "work",
      "focus"
    ],
    "tone": "focused",
    "attribution": null
  },
  {
    "id": "work-focus-011",
    "text": "Your work is not your whole worth.",
    "category": "work-focus",
    "tags": [
      "work",
      "focus"
    ],
    "tone": "focused",
    "attribution": null
  },
  {
    "id": "work-focus-012",
    "text": "A calm mind can still do meaningful work.",
    "category": "work-focus",
    "tags": [
      "work",
      "focus"
    ],
    "tone": "focused",
    "attribution": null
  },
  {
    "id": "work-focus-013",
    "text": "Choose progress that you can sustain.",
    "category": "work-focus",
    "tags": [
      "work",
      "focus"
    ],
    "tone": "focused",
    "attribution": null
  },
  {
    "id": "work-focus-014",
    "text": "Not everything urgent is important.",
    "category": "work-focus",
    "tags": [
      "work",
      "focus"
    ],
    "tone": "focused",
    "attribution": null
  },
  {
    "id": "work-focus-015",
    "text": "Let your effort be focused, not frantic.",
    "category": "work-focus",
    "tags": [
      "work",
      "focus"
    ],
    "tone": "focused",
    "attribution": null
  },
  {
    "id": "money-001",
    "text": "Every thoughtful choice builds steadier ground.",
    "category": "money",
    "tags": [
      "money",
      "progress"
    ],
    "tone": "reassuring",
    "attribution": null
  },
  {
    "id": "money-002",
    "text": "Small savings are still real progress.",
    "category": "money",
    "tags": [
      "money",
      "progress"
    ],
    "tone": "reassuring",
    "attribution": null
  },
  {
    "id": "money-003",
    "text": "Your numbers are information, not a judgment.",
    "category": "money",
    "tags": [
      "money",
      "progress"
    ],
    "tone": "reassuring",
    "attribution": null
  },
  {
    "id": "money-004",
    "text": "Spend in ways that support your life.",
    "category": "money",
    "tags": [
      "money",
      "progress"
    ],
    "tone": "reassuring",
    "attribution": null
  },
  {
    "id": "money-005",
    "text": "You can learn money one choice at a time.",
    "category": "money",
    "tags": [
      "money",
      "progress"
    ],
    "tone": "reassuring",
    "attribution": null
  },
  {
    "id": "money-006",
    "text": "A clear plan can feel like relief.",
    "category": "money",
    "tags": [
      "money",
      "progress"
    ],
    "tone": "reassuring",
    "attribution": null
  },
  {
    "id": "money-007",
    "text": "Progress is more useful than financial perfection.",
    "category": "money",
    "tags": [
      "money",
      "progress"
    ],
    "tone": "reassuring",
    "attribution": null
  },
  {
    "id": "money-008",
    "text": "Make room for joy and responsibility.",
    "category": "money",
    "tags": [
      "money",
      "progress"
    ],
    "tone": "reassuring",
    "attribution": null
  },
  {
    "id": "money-009",
    "text": "Today’s small decision can help future you.",
    "category": "money",
    "tags": [
      "money",
      "progress"
    ],
    "tone": "reassuring",
    "attribution": null
  },
  {
    "id": "money-010",
    "text": "Money can be handled gently and honestly.",
    "category": "money",
    "tags": [
      "money",
      "progress"
    ],
    "tone": "reassuring",
    "attribution": null
  },
  {
    "id": "health-self-care-001",
    "text": "Listen before your body has to shout.",
    "category": "health-self-care",
    "tags": [
      "health",
      "self-care"
    ],
    "tone": "caring",
    "attribution": null
  },
  {
    "id": "health-self-care-002",
    "text": "Care can be simple and still matter.",
    "category": "health-self-care",
    "tags": [
      "health",
      "self-care"
    ],
    "tone": "caring",
    "attribution": null
  },
  {
    "id": "health-self-care-003",
    "text": "Drink water. Unclench your shoulders. Begin there.",
    "category": "health-self-care",
    "tags": [
      "health",
      "self-care"
    ],
    "tone": "caring",
    "attribution": null
  },
  {
    "id": "health-self-care-004",
    "text": "Your body is not an inconvenience.",
    "category": "health-self-care",
    "tags": [
      "health",
      "self-care"
    ],
    "tone": "caring",
    "attribution": null
  },
  {
    "id": "health-self-care-005",
    "text": "Movement can be gentle and still be movement.",
    "category": "health-self-care",
    "tags": [
      "health",
      "self-care"
    ],
    "tone": "caring",
    "attribution": null
  },
  {
    "id": "health-self-care-006",
    "text": "Nourishment is a form of kindness.",
    "category": "health-self-care",
    "tags": [
      "health",
      "self-care"
    ],
    "tone": "caring",
    "attribution": null
  },
  {
    "id": "health-self-care-007",
    "text": "Rest and effort can belong together.",
    "category": "health-self-care",
    "tags": [
      "health",
      "self-care"
    ],
    "tone": "caring",
    "attribution": null
  },
  {
    "id": "health-self-care-008",
    "text": "Choose care that you can return to.",
    "category": "health-self-care",
    "tags": [
      "health",
      "self-care"
    ],
    "tone": "caring",
    "attribution": null
  },
  {
    "id": "health-self-care-009",
    "text": "You deserve support on ordinary days too.",
    "category": "health-self-care",
    "tags": [
      "health",
      "self-care"
    ],
    "tone": "caring",
    "attribution": null
  },
  {
    "id": "health-self-care-010",
    "text": "A slower day can still be healthy.",
    "category": "health-self-care",
    "tags": [
      "health",
      "self-care"
    ],
    "tone": "caring",
    "attribution": null
  },
  {
    "id": "health-self-care-011",
    "text": "Your wellbeing is worth making room for.",
    "category": "health-self-care",
    "tags": [
      "health",
      "self-care"
    ],
    "tone": "caring",
    "attribution": null
  },
  {
    "id": "health-self-care-012",
    "text": "Check in with yourself, not against yourself.",
    "category": "health-self-care",
    "tags": [
      "health",
      "self-care"
    ],
    "tone": "caring",
    "attribution": null
  },
  {
    "id": "love-relationships-001",
    "text": "Love grows in the small, repeated things.",
    "category": "love-relationships",
    "tags": [
      "love",
      "relationships"
    ],
    "tone": "warm",
    "attribution": null
  },
  {
    "id": "love-relationships-002",
    "text": "Make room to listen without preparing an answer.",
    "category": "love-relationships",
    "tags": [
      "love",
      "relationships"
    ],
    "tone": "warm",
    "attribution": null
  },
  {
    "id": "love-relationships-003",
    "text": "Kindness is part of being understood.",
    "category": "love-relationships",
    "tags": [
      "love",
      "relationships"
    ],
    "tone": "warm",
    "attribution": null
  },
  {
    "id": "love-relationships-004",
    "text": "You can be honest and gentle together.",
    "category": "love-relationships",
    "tags": [
      "love",
      "relationships"
    ],
    "tone": "warm",
    "attribution": null
  },
  {
    "id": "love-relationships-005",
    "text": "Connection needs presence more than perfection.",
    "category": "love-relationships",
    "tags": [
      "love",
      "relationships"
    ],
    "tone": "warm",
    "attribution": null
  },
  {
    "id": "love-relationships-006",
    "text": "Say the caring thing while there is time.",
    "category": "love-relationships",
    "tags": [
      "love",
      "relationships"
    ],
    "tone": "warm",
    "attribution": null
  },
  {
    "id": "love-relationships-007",
    "text": "Healthy love leaves room to breathe.",
    "category": "love-relationships",
    "tags": [
      "love",
      "relationships"
    ],
    "tone": "warm",
    "attribution": null
  },
  {
    "id": "love-relationships-008",
    "text": "Let affection be ordinary and often.",
    "category": "love-relationships",
    "tags": [
      "love",
      "relationships"
    ],
    "tone": "warm",
    "attribution": null
  },
  {
    "id": "love-relationships-009",
    "text": "You are allowed to ask for tenderness.",
    "category": "love-relationships",
    "tags": [
      "love",
      "relationships"
    ],
    "tone": "warm",
    "attribution": null
  },
  {
    "id": "love-relationships-010",
    "text": "The right people do not require a smaller you.",
    "category": "love-relationships",
    "tags": [
      "love",
      "relationships"
    ],
    "tone": "warm",
    "attribution": null
  },
  {
    "id": "rest-low-energy-001",
    "text": "Low energy is not a personal failure.",
    "category": "rest-low-energy",
    "tags": [
      "rest",
      "low-energy"
    ],
    "tone": "compassionate",
    "attribution": null
  },
  {
    "id": "rest-low-energy-002",
    "text": "Today may need a softer plan.",
    "category": "rest-low-energy",
    "tags": [
      "rest",
      "low-energy"
    ],
    "tone": "compassionate",
    "attribution": null
  },
  {
    "id": "rest-low-energy-003",
    "text": "Do less, but do it kindly.",
    "category": "rest-low-energy",
    "tags": [
      "rest",
      "low-energy"
    ],
    "tone": "compassionate",
    "attribution": null
  },
  {
    "id": "rest-low-energy-004",
    "text": "Rest before you become completely empty.",
    "category": "rest-low-energy",
    "tags": [
      "rest",
      "low-energy"
    ],
    "tone": "compassionate",
    "attribution": null
  },
  {
    "id": "rest-low-energy-005",
    "text": "Your quiet days still belong to you.",
    "category": "rest-low-energy",
    "tags": [
      "rest",
      "low-energy"
    ],
    "tone": "compassionate",
    "attribution": null
  },
  {
    "id": "rest-low-energy-006",
    "text": "You can pause without losing your way.",
    "category": "rest-low-energy",
    "tags": [
      "rest",
      "low-energy"
    ],
    "tone": "compassionate",
    "attribution": null
  },
  {
    "id": "rest-low-energy-007",
    "text": "Let your body set the pace today.",
    "category": "rest-low-energy",
    "tags": [
      "rest",
      "low-energy"
    ],
    "tone": "compassionate",
    "attribution": null
  },
  {
    "id": "rest-low-energy-008",
    "text": "A smaller plan is still a plan.",
    "category": "rest-low-energy",
    "tags": [
      "rest",
      "low-energy"
    ],
    "tone": "compassionate",
    "attribution": null
  },
  {
    "id": "rest-low-energy-009",
    "text": "You are not behind. You are tired.",
    "category": "rest-low-energy",
    "tags": [
      "rest",
      "low-energy"
    ],
    "tone": "compassionate",
    "attribution": null
  },
  {
    "id": "rest-low-energy-010",
    "text": "Make the day light enough to carry.",
    "category": "rest-low-energy",
    "tags": [
      "rest",
      "low-energy"
    ],
    "tone": "compassionate",
    "attribution": null
  },
  {
    "id": "rest-low-energy-011",
    "text": "Rest can be the most useful choice.",
    "category": "rest-low-energy",
    "tags": [
      "rest",
      "low-energy"
    ],
    "tone": "compassionate",
    "attribution": null
  },
  {
    "id": "rest-low-energy-012",
    "text": "Soft days are still real days.",
    "category": "rest-low-energy",
    "tags": [
      "rest",
      "low-energy"
    ],
    "tone": "compassionate",
    "attribution": null
  },
  {
    "id": "mood-support-001",
    "text": "Feelings can visit without becoming your whole home.",
    "category": "mood-support",
    "tags": [
      "mood",
      "support"
    ],
    "tone": "comforting",
    "attribution": null
  },
  {
    "id": "mood-support-002",
    "text": "You do not have to explain every feeling.",
    "category": "mood-support",
    "tags": [
      "mood",
      "support"
    ],
    "tone": "comforting",
    "attribution": null
  },
  {
    "id": "mood-support-003",
    "text": "Let the emotion move at its own speed.",
    "category": "mood-support",
    "tags": [
      "mood",
      "support"
    ],
    "tone": "comforting",
    "attribution": null
  },
  {
    "id": "mood-support-004",
    "text": "You can be unsettled and still be safe.",
    "category": "mood-support",
    "tags": [
      "mood",
      "support"
    ],
    "tone": "comforting",
    "attribution": null
  },
  {
    "id": "mood-support-005",
    "text": "There is room for more than one feeling.",
    "category": "mood-support",
    "tags": [
      "mood",
      "support"
    ],
    "tone": "comforting",
    "attribution": null
  },
  {
    "id": "mood-support-006",
    "text": "Be curious about what your heart needs.",
    "category": "mood-support",
    "tags": [
      "mood",
      "support"
    ],
    "tone": "comforting",
    "attribution": null
  },
  {
    "id": "mood-support-007",
    "text": "Your feelings are information, not instructions.",
    "category": "mood-support",
    "tags": [
      "mood",
      "support"
    ],
    "tone": "comforting",
    "attribution": null
  },
  {
    "id": "mood-support-008",
    "text": "You are allowed to feel this without fixing it.",
    "category": "mood-support",
    "tags": [
      "mood",
      "support"
    ],
    "tone": "comforting",
    "attribution": null
  },
  {
    "id": "mood-support-009",
    "text": "A hard moment is not the whole day.",
    "category": "mood-support",
    "tags": [
      "mood",
      "support"
    ],
    "tone": "comforting",
    "attribution": null
  },
  {
    "id": "mood-support-010",
    "text": "Hold yourself with the kindness you would offer someone else.",
    "category": "mood-support",
    "tags": [
      "mood",
      "support"
    ],
    "tone": "comforting",
    "attribution": null
  },
  {
    "id": "mood-support-011",
    "text": "You do not need to force brightness.",
    "category": "mood-support",
    "tags": [
      "mood",
      "support"
    ],
    "tone": "comforting",
    "attribution": null
  },
  {
    "id": "mood-support-012",
    "text": "Let calm arrive in small pieces.",
    "category": "mood-support",
    "tags": [
      "mood",
      "support"
    ],
    "tone": "comforting",
    "attribution": null
  },
  {
    "id": "mood-support-013",
    "text": "Take the next moment, not the whole future.",
    "category": "mood-support",
    "tags": [
      "mood",
      "support"
    ],
    "tone": "comforting",
    "attribution": null
  },
  {
    "id": "weather-001",
    "text": "Let the light find you today.",
    "category": "weather",
    "tags": [
      "weather",
      "sunny"
    ],
    "tone": "atmospheric",
    "attribution": null
  },
  {
    "id": "weather-002",
    "text": "A little cloud does not cancel the light.",
    "category": "weather",
    "tags": [
      "weather",
      "partly-cloudy"
    ],
    "tone": "atmospheric",
    "attribution": null
  },
  {
    "id": "weather-003",
    "text": "Grey skies can still hold gentle days.",
    "category": "weather",
    "tags": [
      "weather",
      "cloudy"
    ],
    "tone": "atmospheric",
    "attribution": null
  },
  {
    "id": "weather-004",
    "text": "Let the rain make the world quieter.",
    "category": "weather",
    "tags": [
      "weather",
      "rain"
    ],
    "tone": "atmospheric",
    "attribution": null
  },
  {
    "id": "weather-005",
    "text": "Stay close to what feels steady.",
    "category": "weather",
    "tags": [
      "weather",
      "storm"
    ],
    "tone": "atmospheric",
    "attribution": null
  },
  {
    "id": "weather-006",
    "text": "Let the wind carry off what feels heavy.",
    "category": "weather",
    "tags": [
      "weather",
      "windy"
    ],
    "tone": "atmospheric",
    "attribution": null
  },
  {
    "id": "weather-007",
    "text": "You only need to see the next step.",
    "category": "weather",
    "tags": [
      "weather",
      "fog"
    ],
    "tone": "atmospheric",
    "attribution": null
  },
  {
    "id": "weather-008",
    "text": "Something beautiful can follow a difficult sky.",
    "category": "weather",
    "tags": [
      "weather",
      "rainbow"
    ],
    "tone": "atmospheric",
    "attribution": null
  },
  {
    "id": "weather-009",
    "text": "The world knows how to pause.",
    "category": "weather",
    "tags": [
      "weather",
      "snow"
    ],
    "tone": "atmospheric",
    "attribution": null
  },
  {
    "id": "weather-010",
    "text": "Move slowly beneath the bright day.",
    "category": "weather",
    "tags": [
      "weather",
      "hot"
    ],
    "tone": "atmospheric",
    "attribution": null
  },
  {
    "id": "celebrations-001",
    "text": "Your life is worth celebrating, exactly as it is.",
    "category": "celebrations",
    "tags": [
      "celebration",
      "birthday"
    ],
    "tone": "joyful",
    "attribution": null
  },
  {
    "id": "celebrations-002",
    "text": "Begin the year with hope, not pressure.",
    "category": "celebrations",
    "tags": [
      "celebration",
      "new-year"
    ],
    "tone": "joyful",
    "attribution": null
  },
  {
    "id": "celebrations-003",
    "text": "Love can be soft, steady, and everyday.",
    "category": "celebrations",
    "tags": [
      "celebration",
      "valentines-day"
    ],
    "tone": "joyful",
    "attribution": null
  },
  {
    "id": "celebrations-004",
    "text": "A little magic belongs in ordinary life.",
    "category": "celebrations",
    "tags": [
      "celebration",
      "halloween"
    ],
    "tone": "joyful",
    "attribution": null
  },
  {
    "id": "celebrations-005",
    "text": "New beginnings can arrive quietly.",
    "category": "celebrations",
    "tags": [
      "celebration",
      "easter-spring"
    ],
    "tone": "joyful",
    "attribution": null
  },
  {
    "id": "celebrations-006",
    "text": "Keep the warmth, release the rush.",
    "category": "celebrations",
    "tags": [
      "celebration",
      "christmas"
    ],
    "tone": "joyful",
    "attribution": null
  },
  {
    "id": "celebrations-007",
    "text": "Pause long enough to feel proud.",
    "category": "celebrations",
    "tags": [
      "celebration",
      "achievement"
    ],
    "tone": "joyful",
    "attribution": null
  },
  {
    "id": "celebrations-008",
    "text": "Joy deserves a place on the calendar.",
    "category": "celebrations",
    "tags": [
      "celebration",
      "general-celebration"
    ],
    "tone": "joyful",
    "attribution": null
  }
];

export default stillQuotes;
